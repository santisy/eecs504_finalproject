function rotatedImage = rotatectr(image,degree,column,row)
[n,m,l] = size(image);
T1 = maketform('affine',[1 0 0; 0 1 0; -column -row 1]);
R1 = maketform('affine',[cosd(-degree) sind(-degree) 0; -sind(-degree) cosd(-degree) 0; 0 0 1]);
T2 = maketform('affine',[1 0 0; 0 1 0; column row 1]);
transMat = maketform('composite', T2, R1, T1);
rotatedImage = imtransform(image, transMat, 'XData', [1 m], 'YData', [1 n]);
