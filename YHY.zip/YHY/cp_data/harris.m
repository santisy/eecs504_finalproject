function C = harris(dx,dy,Whalfsize)

% function C = harris(dx,dy,Whalfsize)
%
%     EECS Foundation of Computer Vision;
%     Jason Corso
%
%   I is the image (GRAY, DOUBLE)
%   or
%   dx is the horizontal gradient image
%   dy is the vertical gradient image
%
%   If you call it with the Image I, then you need set parameter dy to []
%
%   Whalfsize is the half size of the window.  Wsize = 2*Whalfsize+1
%
%   Corner strength is taken as min(eig) and not the det(T)/trace(T) as in
%   the original harris method.  Just for simplicity
%
%  output
%   C is an image (same size as dx and dy) where every pixel contains the
%   corner strength.  


if (isempty(dy))
   im = dx; 
   dy = conv2(im,fspecial('sobel'),'same');
   dx = conv2(im,fspecial('sobel')','same'); 
end


%%%%%%%%% fill in below
% Corner strength is to be taken as min(eig) and not the det(T)/trace(T) as in
%  the original harris method.
% padding the two functions the window for everypoint is valiad
dxp = padarray(dx,[Whalfsize Whalfsize],0);
dyp = padarray(dy,[Whalfsize Whalfsize],0); 

% turn image into patches (column represented)
dxpPatches = im2col(dxp, [Whalfsize*2+1 Whalfsize*2+1], 'sliding')';
dypPatches = im2col(dyp, [Whalfsize*2+1 Whalfsize*2+1], 'sliding')';
% initialize C
sizeC = size(dx);
C = zeros(sizeC);
% calculate every entry of C by SVD
for i = 1:sizeC(1)% iteration through rows
    for j = 1:sizeC(2) %iteration through columns
        pixIdx = sizeC(1)*(j-1)+i;
        I = [(dxpPatches(pixIdx,:)*dxpPatches(pixIdx,:)'),(dxpPatches(pixIdx,:)*dypPatches(pixIdx,:)');(dxpPatches(pixIdx,:)*dypPatches(pixIdx,:)'),(dypPatches(pixIdx,:)*dypPatches(pixIdx,:)')];
        [~,A] = eig(I); % do the SVD for structure tensor
        C(i,j) = min(sum(A)); %minimum
    end
end

        

 

